"""Free Google Translate API for Python. Translates totally free of charge."""
__all__ = ('Google_translator', "bing_translator")
__version__ = '0.0.1'

from google_bing_trans.googletrans.translation import Google_translator
from google_bing_trans.bingtrans import bing_translator
