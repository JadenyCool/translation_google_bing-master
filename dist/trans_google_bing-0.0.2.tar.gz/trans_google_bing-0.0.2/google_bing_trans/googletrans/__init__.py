

from google_bing_trans.googletrans.translation import Google_translator
from google_bing_trans.googletrans.constants import LANGCODES, LANGUAGES  # noqa